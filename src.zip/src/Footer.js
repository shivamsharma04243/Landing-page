import React from 'react';
import ContactForm from './Contact_form';
const Footer = () => {
  return (
    <footer className="footer bg-white text-dark">
     <div className="flex-grow-1 container-fluid">
        <div className="row p-5 shadow-lg" style={{ marginTop: 'auto', backgroundColor: "aliceblue", borderRadius: "10px" }}>
          <div className="col-md-6" >
           

            
           
              <div  style={{ marginTop: '50%', color: '#1e3a8a' }}>
               <h5>Contact Information</h5>
               <p>Email: bhutani123@gmail.com</p>
                <p>Phone: 123-456-7890</p>
              </div>
          
           
            
          </div>
          <div className="col-md-6">
            <h2 style={{ fontFamily: 'Merriweather, sans-serif', color: '#1e3a8a' }}>M3M The Line</h2>
            <p style={{ fontFamily: 'Merriweather, sans-serif', color: '#1e3a8a' }}>
              M3M Sector 72 Noida
            </p>
           <ContactForm/>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
